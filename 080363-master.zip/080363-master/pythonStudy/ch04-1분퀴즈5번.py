animal_list = ["강아지", "고양이"]
sound_list = ["멍멍", "야옹"]
for animal, sound in zip(animal_list, sound_list):
    print(f"{animal} : {sound}.")