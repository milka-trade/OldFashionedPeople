num1 = int(input("첫 번째 숫자 입력 >> "))
num2 = int(input("두 번째 숫자 입력 >> "))
print(num1 * num2)