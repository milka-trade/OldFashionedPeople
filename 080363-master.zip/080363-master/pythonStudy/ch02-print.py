print("안녕하세요!")
print(12.345) # 숫자 출력
print(["A", "B", "C"]) # 리스트 출력
print({"짜장":5000, "짬뽕":6000}) # 딕셔너리 출력
print("홍길동", 25, "남자") # 여러 값 출력
foo = "Hello World!" # 변수에 문자열 저장
print(foo) # 변숫값 출력
print("안녕하세요.", end=" ") # end 옵션 사용
print("저는 파이썬을 배우는 중입니다.")
print("안녕하세요.", end="abcd")
print("저는 파이썬을 배우는 중입니다.")
print("안녕하세요.", end="1234")
print("저는 파이썬을 배우는 중입니다.")