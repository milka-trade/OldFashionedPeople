# 함수 정의
def add(a, b):
    c = a + b
    return c
# 함수 호출
result = add(10, 20)
print(result) 