x = 0
while x < 5:
    x += 1
    if x == 2:
        continue
    if x == 4:
        break
    print(x)