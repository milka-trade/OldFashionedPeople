def multiply_by_two(n):
    return n * 2
def add_numbers(a, b):
    return a + b
result = multiply_by_two(add_numbers(3, 2))
print(result)