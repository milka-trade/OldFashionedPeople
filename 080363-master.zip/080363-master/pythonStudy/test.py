print("Hello World")
print(10 + 20)
print(len("Hello"))