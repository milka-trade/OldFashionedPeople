# 모듈을 불러오는 방법 1: import
# import calendar
# calendar.prcal(2024)

# 모듈을 불러오는 방법 2: import ~ as
# import calendar as cal
# cal.prcal(2024)

# 모듈을 불러오는 방법 3: from ~ import
from calendar import prcal
prcal(2024)