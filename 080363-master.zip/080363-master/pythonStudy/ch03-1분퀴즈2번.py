num1 = 10
num2 = 4
print(num1 + num2 - 4 != 10)