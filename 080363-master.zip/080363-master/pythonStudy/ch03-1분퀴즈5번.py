weather = ["맑음", "눈", "흐림", "천둥번개", "비"] # ( )를 [ ]로 수정
weather.append("안개") # "weather =" 삭제
weather.remove("천둥번개") # ["천둥번개"]를 "천둥번개"로 수정
print(weather[-4:-1]) # [-1:-4]를 [-4:-1]로 수정