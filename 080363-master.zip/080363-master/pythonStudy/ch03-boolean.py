print(True and True, True and False, False and True, False and False)
print(True or True, True or False, False or True, False or False)
print(not True, not False)

num1 = 20
num2 = 10
print(num1 >= 10 and num2 <= 30) # True and True
print(num1 == 20 or num2 == 5) # True or False
print(not num1 == 20) # not True