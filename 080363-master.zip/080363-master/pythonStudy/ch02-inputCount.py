foo = input("문자열 입력 >> ")
print(len(foo))