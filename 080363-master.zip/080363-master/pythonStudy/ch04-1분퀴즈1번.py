num = 10
if num >= 5:
    print("Hello")
else:
    print("World")
if num >= 30:
    print("Hello")
else:
    print("Python")